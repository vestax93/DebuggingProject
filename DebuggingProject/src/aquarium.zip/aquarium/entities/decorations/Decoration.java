package aquarium.entities.decorations;

public interface Decoration {
    int getComfort();

    double getPrice();
}
